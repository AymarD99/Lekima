//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Dang Ngoc on 5/29/20.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
