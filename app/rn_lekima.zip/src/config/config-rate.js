export default {
  AppleAppID: '1511705353',
  GooglePackageName: 'io.rnlab.lekima',
  preferInApp: true,
  openAppStoreIfInAppFails: true,
};
