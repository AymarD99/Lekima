export const ENABLE_CONFIG_DEMO = false;
