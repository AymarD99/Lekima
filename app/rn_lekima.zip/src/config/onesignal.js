export const APP_ID = 'YOUR_ONE_SIGNAL_API_KEY';
