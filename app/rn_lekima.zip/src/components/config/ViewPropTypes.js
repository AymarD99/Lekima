import {View, ViewPropTypes as RNViewPropTypes} from 'react-native';

const ViewPropTypes = RNViewPropTypes || View.propTypes;

export default ViewPropTypes;
