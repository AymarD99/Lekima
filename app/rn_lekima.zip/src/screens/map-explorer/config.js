export const MIN_RADIUS = 0;
export const MAX_RADIUS = 500;
export const INIT_SORTBY = {
  orderby: null,
  wcfmmp_radius_range: 50,
  wcfmmp_store_category: null,
  search_term: null,
};
