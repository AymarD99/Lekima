import {StyleSheet} from 'react-native';
import {lineHeights} from 'src/components/config/fonts';

export default StyleSheet.create({
  text: {
    lineHeight: lineHeights.h4,
  },
});
